const puppeteer = require('puppeteer');

(async () => {
  const browser = await puppeteer.launch({
    headless: "new", // Opt into the new headless mode
    args: ['--no-sandbox', '--disable-setuid-sandbox'] // Run without sandbox
  });
  const page = await browser.newPage();
  await page.goto('https://example.com');
  console.log(await page.title());
  await browser.close();
})();

